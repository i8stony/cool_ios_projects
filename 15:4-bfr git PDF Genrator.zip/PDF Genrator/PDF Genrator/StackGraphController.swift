//
//  StackGraphController.swift
//  Graphs in swift Storyboard
//
//  Created by Keshav Pawar on 15/04/24.
//

import UIKit
import Charts

class StackGraphController: UIViewController {
    
    @IBOutlet weak var mainView: UIView!
    
    
    @IBOutlet weak var barChartView: BarChartView! //stack bar
    @IBOutlet weak var pieChartView: PieChartView! //pie chart
    
    @IBOutlet weak var positiveLineChartView: LineChartView! //line +
    @IBOutlet weak var negativeLineChartView: LineChartView! // line -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        positiveLineChartView.isUserInteractionEnabled = false
        negativeLineChartView.isUserInteractionEnabled = false
        barChartView.isUserInteractionEnabled = false
        
        
        
        
        addCellShadow(to: pieChartView)
        addCellShadow(to: barChartView)
        
        //        //call graph methods
        //        pieChartSetup()
        //        barChartSetup()
        //        positiveLineChartSetup()
        //        negativeLineChartSetup()
        
        
        // Call the setup methods with a 1-second interval
        setupChartsWithInterval()
    }
    
    //call all graph with 1 sec delay
    func setupChartsWithInterval() {
        let setupMethods: [() -> Void] = [pieChartSetup, barChartSetup, positiveLineChartSetup, negativeLineChartSetup]
        var index = 0
        
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            if index < setupMethods.count {
                setupMethods[index]()
                index += 1
            } else {
                timer.invalidate()
            }
        }
    }
    
    //shadow to graphs
    func addCellShadow(to view: UIView) {
        view.layer.shadowColor = UIColor.gray.cgColor
        view.layer.shadowOpacity = 0.8
        view.layer.shadowOffset = CGSize(width: 0, height: 4)
        view.layer.shadowRadius = 8
        view.layer.masksToBounds = false
    }
    
    
    // MARK: - PieChart
    func pieChartSetup() {
        setDataCountPie(2, range: 100)
        
        // Optionally, add some styling
        pieChartView.drawEntryLabelsEnabled = false // Disable labels on the pie slices
        pieChartView.legend.enabled = true // Enable legend
        pieChartView.legend.textColor = .black // Set legend text color
        pieChartView.legend.font = UIFont.systemFont(ofSize: 12) // Set legend font
        pieChartView.legend.horizontalAlignment = .center // Set legend alignment
        pieChartView.legend.verticalAlignment = .bottom // Set legend position
        
        // Animate the presentation of the chart
        pieChartView.animate(xAxisDuration: 1.0, easingOption: .linear)
    }
    
    func setDataCountPie(_ count: Int, range: UInt32) {
        let entries = (0..<count).map { (i) -> PieChartDataEntry in
            return PieChartDataEntry(value: Double(arc4random_uniform(range) + range / 5),
                                     label: i == 0 ? "Sales" : "Expenses")
        }
        
        let set = PieChartDataSet(entries: entries, label: "")
        set.drawIconsEnabled = false
        set.sliceSpace = 2
        
        set.colors = [UIColor.green, UIColor.red] // Set colors for sales and expenses
        
        let data = PieChartData(dataSet: set)
        
        let pFormatter = NumberFormatter()
        pFormatter.numberStyle = .percent
        pFormatter.maximumFractionDigits = 1
        pFormatter.multiplier = 1
        pFormatter.percentSymbol = " %"
        data.setValueFormatter(DefaultValueFormatter(formatter: pFormatter))
        
        data.setValueFont(.systemFont(ofSize: 11, weight: .light))
        data.setValueTextColor(.black)
        
        pieChartView.data = data
        pieChartView.highlightValues(nil)
        
    }
    
    // MARK: - StackBar Chart
    func barChartSetup() {
        setDataCountBar(12, range: 100)
        
        // Optionally, add some styling
        barChartView.drawValueAboveBarEnabled = false // Disable data values above bars
        barChartView.drawBarShadowEnabled = false // Disable bar shadows
        barChartView.legend.enabled = false // Disable legend
        barChartView.xAxis.enabled = false // Disable x-axis
        barChartView.leftAxis.enabled = false // Disable left y-axis
        barChartView.rightAxis.enabled = false // Disable right y-axis
        
        //zoom disabled
        barChartView.scaleXEnabled = false // Disable x-axis scaling
        barChartView.scaleYEnabled = false // Disable y-axis scaling
        barChartView.pinchZoomEnabled = false
        
        // Animate the presentation of the chart
        barChartView.animate(xAxisDuration: 2.0, easingOption: .linear)
    }
    
    func setDataCountBar(_ count: Int, range: UInt32) {
        let salesEntries = (0..<count).map { (i) -> BarChartDataEntry in
            return BarChartDataEntry(x: Double(i), yValues: [Double(arc4random_uniform(range) + range / 5)])
        }
        
        let expenseEntries = (0..<count).map { (i) -> BarChartDataEntry in
            return BarChartDataEntry(x: Double(i), yValues: [Double(arc4random_uniform(range) + range / 5)])
        }
        
        let salesSet = BarChartDataSet(entries: salesEntries, label: "")
        salesSet.setColor(UIColor.green)
        salesSet.drawValuesEnabled = false // Disable data values for this dataset
        
        let expenseSet = BarChartDataSet(entries: expenseEntries, label: "")
        expenseSet.setColor(UIColor.red)
        expenseSet.drawValuesEnabled = false // Disable data values for this dataset
        
        // Add stack labels
        salesSet.stackLabels = ["Sales"]
        expenseSet.stackLabels = ["Expenses"]
        
        let data = BarChartData(dataSets: [salesSet, expenseSet])
        barChartView.data = data
    }
    
    
    // MARK: - + LIneChart
    func positiveLineChartSetup() {
        setDataCountPositiveLine(12, range: 100)
        
        // Optionally, add some styling
        positiveLineChartView.legend.enabled = false // Disable legend
        
        let xAxis = positiveLineChartView.xAxis
        xAxis.labelPosition = .bottom
        xAxis.labelFont = .systemFont(ofSize: 10)
        xAxis.labelTextColor = .black
        xAxis.drawAxisLineEnabled = true
        xAxis.drawGridLinesEnabled = false
        xAxis.granularity = 1 // Ensure that each month has a separate label
        xAxis.valueFormatter = IndexAxisValueFormatter(values: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"])
        xAxis.labelCount = 12 // Set the label count to ensure all 12 months are displayed
        xAxis.avoidFirstLastClippingEnabled = true // Avoid clipping the first and last labels
        xAxis.spaceMax = 0.5 // Adjust the maximum space between labels as needed
        xAxis.labelRotationAngle = -45 // Rotate labels to prevent overlapping
        
        // Adjust bottom margin to prevent cropping
        positiveLineChartView.extraBottomOffset = 20.0 // Adjust this value as needed
        
        // Configure left y-axis
        let leftAxis = positiveLineChartView.leftAxis
        leftAxis.enabled = true
        leftAxis.labelFont = .systemFont(ofSize: 10)
        leftAxis.labelTextColor = .black
        leftAxis.axisMinimum = 0
        leftAxis.axisMaximum = 2000
        leftAxis.drawAxisLineEnabled = true
        leftAxis.drawGridLinesEnabled = true
        leftAxis.granularityEnabled = true
        
        // Configure right y-axis
        let rightAxis = positiveLineChartView.rightAxis
        rightAxis.enabled = false
        
        //zoom disabled
        positiveLineChartView.scaleXEnabled = false // Disable x-axis scaling
        positiveLineChartView.scaleYEnabled = false // Disable y-axis scaling
        positiveLineChartView.pinchZoomEnabled = false
        
        // Disable crosshairs
        positiveLineChartView.drawMarkers = false
        
        // Customize the line
        let dataSet = positiveLineChartView.data?.dataSets.first as? LineChartDataSet
        dataSet?.colors = [UIColor.systemPink] // Set line color
        dataSet?.circleColors = [UIColor.systemPink]
        dataSet?.circleHoleColor = UIColor.systemPink
        dataSet?.circleRadius = 3.5
        dataSet?.lineWidth = 3.0
        dataSet?.mode = .cubicBezier // Set line mode to cubic Bezier for curved line
        dataSet?.fillColor = UIColor.systemPink // Set fill color under the line
        dataSet?.drawFilledEnabled = true // Enable drawing filled region under the line
        
        // Animate the presentation of the chart
        positiveLineChartView.animate(xAxisDuration: 3.0, easingOption: .linear)
    }

    func setDataCountPositiveLine(_ count: Int, range: UInt32) {
        // Generate increasing values
        let entries = (0..<count).map { (i) -> ChartDataEntry in
            return ChartDataEntry(x: Double(i), y: Double(arc4random_uniform(range)) + Double(i * 120))
        }
        
        let dataSet = LineChartDataSet(entries: entries, label: "")
        dataSet.drawValuesEnabled = false // Disable data values for this dataset
        
        let data = LineChartData(dataSet: dataSet)
        positiveLineChartView.data = data
    }
    
    // MARK: - - line Chart
    func negativeLineChartSetup() {
        setDataCountNegativeLine(12, range: 100)
        // Optionally, add some styling
        negativeLineChartView.legend.enabled = false // Disable legend
        
        // Configure x-axis
        let xAxis = negativeLineChartView.xAxis
        xAxis.labelPosition = .bottom
        xAxis.labelFont = .systemFont(ofSize: 10)
        xAxis.labelTextColor = .black
        xAxis.drawAxisLineEnabled = true
        xAxis.drawGridLinesEnabled = false
        xAxis.granularity = 1 // Ensure that each month has a separate label
        xAxis.valueFormatter = IndexAxisValueFormatter(values: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"])
        xAxis.labelCount = 12 // Set the label count to ensure all 12 months are displayed
        xAxis.avoidFirstLastClippingEnabled = true // Avoid clipping the first and last labels
        xAxis.spaceMax = 0.5 // Adjust the maximum space between labels as needed
        xAxis.labelRotationAngle = -45 // Rotate labels to prevent overlapping
        
        // Adjust bottom margin to prevent cropping
        negativeLineChartView.extraBottomOffset = 20.0 // Adjust this value as needed
        
        // Configure left y-axis
        let leftAxis = negativeLineChartView.leftAxis
        leftAxis.enabled = true
        leftAxis.labelFont = .systemFont(ofSize: 10)
        leftAxis.labelTextColor = .black
        leftAxis.axisMinimum = 0
        leftAxis.axisMaximum = 2000
        leftAxis.drawAxisLineEnabled = true
        leftAxis.drawGridLinesEnabled = true
        leftAxis.granularityEnabled = true
        
        // Configure right y-axis
        let rightAxis = negativeLineChartView.rightAxis
        rightAxis.enabled = false
        
        //zoom disabled
        negativeLineChartView.scaleXEnabled = false // Disable x-axis scaling
        negativeLineChartView.scaleYEnabled = false // Disable y-axis scaling
        negativeLineChartView.pinchZoomEnabled = false
        
        // Customize the line
        let dataSet = negativeLineChartView.data?.dataSets.first as? LineChartDataSet
        dataSet?.colors = [UIColor.systemBlue] // Set line color
        dataSet?.circleColors = [UIColor.systemBlue]
        dataSet?.circleHoleColor = UIColor.systemBlue
        dataSet?.circleRadius = 3.5
        dataSet?.lineWidth = 3.0
        dataSet?.mode = .cubicBezier // Set line mode to cubic Bezier for curved line
        dataSet?.fillColor = UIColor.systemBlue // Set fill color under the line
        dataSet?.drawFilledEnabled = true // Enable drawing filled region under the line
        
        // Animate the presentation of the chart
        negativeLineChartView.animate(xAxisDuration: 3.0, easingOption: .linear)
    }
    func setDataCountNegativeLine(_ count: Int, range: UInt32) {
        // Generate decreasing values
        let entries = (0..<count).map { (i) -> ChartDataEntry in
            return ChartDataEntry(x: Double(i), y: Double(arc4random_uniform(range)) + Double((count - i) * 120))
        }
        
        let dataSet = LineChartDataSet(entries: entries, label: "")
        dataSet.drawValuesEnabled = false // Disable data values for this dataset
        
        let data = LineChartData(dataSet: dataSet)
        negativeLineChartView.data = data
    }
   
    
}



